#include "TM4C123GH6PM.h"
#include "q1.h"
int main()
{
//run_motor(159999,0);//0 means CCW,1 means CW
	GPIOC_init();
	int dummy_index=0,speed=1599999;
	//run_motor(159999,1);
while(1)
	{
		a++;
		if(GPIOC->DATA == 0xED)
		{	
			while(GPIOC->DATA == 0xED)
			{
				dummy_index++;
			}
			rotation=1;
			run_motor(speed,rotation);
		}
		else if(GPIOC->DATA == 0xDD)
		{	
			while(GPIOC->DATA == 0xDD)
			{
				dummy_index++;
			}
			rotation=0;
			run_motor(speed,rotation);
		}
		else if(GPIOC->DATA == 0xBD)
		{	
			while(GPIOC->DATA == 0xBD)
			{
				dummy_index++;
			}
			speed=speed/2;
			run_motor(speed,rotation);
		}
		else if(GPIOC->DATA == 0x7D)
		{	
			while(GPIOC->DATA == 0x7D)
			{
				dummy_index++;
			}
			speed=speed*2;
			run_motor(speed,rotation);
		}
		
	}
	
}